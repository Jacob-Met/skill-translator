import {createAppServer} from './server.mjs';
const major=Number(process.versions.node.split('.')[0]);
if(major<20)throw Error('Node.js 20 or later is required.');
const port=Number(process.env.PORT||8787);
if(!Number.isInteger(port)||port<1||port>65535)throw Error('Invalid PORT');
const server=createAppServer();
server.on('error',error=>{console.error('Cannot start Task Space Lab:',error.message);process.exitCode=1;});
server.listen(port,'127.0.0.1',()=>console.log('Task Space Lab: http://127.0.0.1:'+port+' (Ctrl+C to stop)'));
