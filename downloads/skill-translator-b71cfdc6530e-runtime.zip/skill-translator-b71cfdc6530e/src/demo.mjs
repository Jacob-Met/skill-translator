// Synthetic bookbinding registration demonstration; not a camera measurement.
// The points are authored illustrative pixel annotations; no force/contact data.
export const demonstration=Object.freeze({
  title:"Bookbinding · three registration landmarks",
  provenance:"Illustrative authored 2D frame; no measured video, force or expert validation.",
  source:{
    widthMm:240,heightMm:160,
    corners:[{x:70,y:60},{x:470,y:80},{x:440,y:340},{x:55,y:310}]
  },
  landmarks:[
    {id:"spine-clearance",label:"Spine guide clearance",kind:"edge_offset_mm",
      edge:"left",sourcePx:{x:88.5,y:189.0},toleranceMm:3,
      why:"Keep the physical clearance from the sheet's left/spine edge as its size changes."},
    {id:"center-registration",label:"Center registration",kind:"fraction",
      sourcePx:{x:258.6,y:198.3},toleranceMm:5,
      why:"Retain the page's center as a fraction of its width and height."},
    {id:"top-index",label:"Top-edge indexing",kind:"edge_offset_mm",
      edge:"top",sourcePx:{x:377.6,y:110.1},toleranceMm:4,
      why:"Keep physical distance from the top edge while retaining the along-edge fraction."}
  ],
  unknowns:[
    "Contact pressure and paper resistance were not measured.",
    "Grain direction, adhesive choice and safe tool handling require expert review.",
    "Marker geometry alone does not prove successful physical bookbinding."
  ]
});
